package com.product.catalogue.controller;


import com.product.catalogue.exception.CatalogueException;
import com.product.catalogue.model.Product;
import com.product.catalogue.model.PurchaseResponse;
import com.product.catalogue.repository.CatalogueRepository;
import com.product.catalogue.service.CatalogueService;
import com.sun.org.apache.xml.internal.resolver.CatalogException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletMapping;
import java.util.List;

@RestController
public class CatalogueController {

    @Autowired
    CatalogueRepository catalogueRepository;

    @Autowired
    CatalogueService catalogueService;

    @GetMapping("/products")
    public List<Product> getAllProducts(){
        return catalogueRepository.findAll();
    }

    @GetMapping("/products/{id}")
    public Product getProduct(@PathVariable Long id) throws CatalogueException {
        return catalogueRepository.findById(id).orElseThrow(()->new CatalogueException("Product not found"));
    }



    @PostMapping("/products")
    @ResponseStatus(HttpStatus.CREATED)
    public void saveProduct(@RequestBody Product product) throws CatalogueException {
        if(product.getAvailability()<0) throw new CatalogueException("Availability cannot be less than 0");
        catalogueRepository.save(product);
    }

    @PutMapping("/products/{id}")
    public void replaceProduct(@RequestBody Product newProduct,@PathVariable Long id) {
        catalogueRepository.findById(id).map(product->{
            product.setDescription(newProduct.getDescription());
            product.setPrice(newProduct.getPrice());
            return catalogueRepository.save(product);
        }).orElseGet(()->{
            newProduct.setId(id);
            return catalogueRepository.save(newProduct);
        });
    }

    @PostMapping("/purchase")
    public ResponseEntity<String> purchaseProduct(@RequestParam(name = "id") Long id , @RequestParam(name = "quantity") int quantity) {
        PurchaseResponse response = catalogueService.purchase(id,quantity);
        HttpHeaders headers = new HttpHeaders();
        if(response.getValue()==0) {
            return new ResponseEntity<>(
                    response.getMessage(), headers, HttpStatus.OK);
        }else{
            return new ResponseEntity<>(
                    response.getMessage(), headers, HttpStatus.NOT_ACCEPTABLE);
        }

    }

    @DeleteMapping("/products/{id}")
    public void deleteProduct(@PathVariable Long id){
        catalogueRepository.deleteById(id);
    }


}
