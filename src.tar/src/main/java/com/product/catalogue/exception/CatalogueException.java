package com.product.catalogue.exception;

public class CatalogueException extends Exception{

    public CatalogueException(String message){
        super(message);
    }
}
