package com.product.catalogue.config;

import com.product.catalogue.model.Product;
import com.product.catalogue.repository.CatalogueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class InitLoad {

    @Autowired
    CatalogueRepository catalogueRepository;
    @Bean
    CommandLineRunner init(){
        return args -> {
            System.out.println("Preloading..." + catalogueRepository.save(new Product("iPad","A tablet",500.00,10)));
            System.out.println("Preloading..." + catalogueRepository.save(new Product("iPhone","A Phone",600.00,10)));
        };

    }

}


