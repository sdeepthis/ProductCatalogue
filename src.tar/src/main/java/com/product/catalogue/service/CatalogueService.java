package com.product.catalogue.service;

import com.product.catalogue.model.Product;
import com.product.catalogue.model.PurchaseResponse;
import com.product.catalogue.repository.CatalogueRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class CatalogueService {

    private static Logger LOGGER = LoggerFactory.getLogger(CatalogueService.class);
    @Autowired
    CatalogueRepository catalogueRepository;


    public PurchaseResponse purchase(Long id, int quantity){
        PurchaseResponse response = new PurchaseResponse();
        if(!catalogueRepository.findById(id).isPresent()){
            LOGGER.error("Product does not exist : " + id);
            response.setMessage("Product does not exist : " + id);
            response.setValue(-1);
            return  response;
        }
        Product product = catalogueRepository.findById(id).get();

        if(quantity <0){
            LOGGER.error("Purchase quantity cannot be less than 0 : " + quantity );
            response.setMessage("Purchase quantity cannot be less than 0 : " + quantity );
            response.setValue(-1);
            return response;
        }
        if(product.getAvailability()>=quantity){
            product.setAvailability(product.getAvailability() - quantity);
            catalogueRepository.save(product);
            LOGGER.info("Product purchase successful");
            response.setMessage("Product purchase successful");
            response.setValue(0);

        }else{
            LOGGER.info("Product purchase is not successful. Quantity : " + quantity + " Availability: " + product.getAvailability());
            response.setMessage("Product purchase is not successful. Quantity : " + quantity + " Availability: " + product.getAvailability());
            response.setValue(-1);
        }
        return  response;
    }


}
