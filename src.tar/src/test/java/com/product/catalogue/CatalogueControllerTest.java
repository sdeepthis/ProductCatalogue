package com.product.catalogue;

import static io.restassured.RestAssured.get;

import com.product.catalogue.model.Product;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.Before;
import org.junit.Test;
import org.springframework.web.bind.annotation.*;

import static io.restassured.RestAssured.with;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.hasItems;

@RestController
public class CatalogueControllerTest {

    @Before
    public void setUp() throws Exception {
        RestAssured.baseURI="http://localhost";
        RestAssured.port=8080;
    }

    @Test
    public void getAllProducts() {

        get("/products").then().statusCode(200).body("name",hasItems("iPad","iPhone"));
    }

    @Test
    public void getProduct() {
        get("/products/1")
                .then()
                .statusCode(200)
                .body("id",equalTo(1))
                .body("name",equalTo("iPad"));
    }

    @Test
    public void saveProduct() {
        with().body(new Product("iWatch-2","A V2 Watch",100.00,20))
                .contentType(ContentType.JSON)
                .when()
                .request("POST","/products")
                .then()
                .statusCode(201);
    }


}
