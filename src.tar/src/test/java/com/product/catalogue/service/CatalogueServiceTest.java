package com.product.catalogue.service;

import static org.junit.Assert.*;

public class CatalogueServiceTest {



}